<?php 

/*
Plugin Name: firsttheme metaboxes
Plugin URI: 
Description: Adding metaboxes for firsttheme
version: 1.0.0
Author: Nebur242
Author URI: http://nzaou.dba.ma
Licence: GPL2
Text Domain: firstthem-metaboxes
Domain Path: /languages


*/

if(!defined('WPINC')){
    die;
}


include_once('includes/metaboxes.php');
include_once('includes/inqueue-assets.php');

?>