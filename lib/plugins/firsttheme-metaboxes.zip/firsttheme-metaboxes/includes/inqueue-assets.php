<?php 

    function firsttheme_metaboxes_admin_scripts(){

        global $pagenow;
        if($pagenow !== 'post.php') return;
        wp_enqueue_script( 
            'firsttheme-metaboxes-admin-scripts',
            plugins_url( 'FirstTheme-metaboxes/dist/assets/js/admin.js'),
            array('jquery') ,
            '1.0.0',
            'all'
        );

        wp_enqueue_style( 
            'firsttheme-metaboxes-admin-stylesheet',
            plugins_url( 'FirstTheme-metaboxes/dist/assets/css/style.css' ),
            array() ,
            '1.0.0',
            'all'
        );
    }

    add_action('admin_enqueue_scripts', 'firsttheme_metaboxes_admin_scripts');

?>